
package edu.upc.epsevg.prop.othello;

/**
 *
 * @author Usuari
 */
public class ElMeuStatus extends GameStatus {
    
    public ElMeuStatus(int [][] tauler){
        super(tauler);
    }
    
     public ElMeuStatus(GameStatus gs){
        super(gs);
    }
    
}
